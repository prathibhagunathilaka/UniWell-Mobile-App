// Keep this import first: it installs the app-wide text scaling before any screen renders.
import { FontScaleProvider } from '@/contexts/FontScaleContext';
import { DarkTheme, DefaultTheme, Stack, ThemeProvider } from 'expo-router';
import { useColorScheme, View } from 'react-native';

import { AuthRouteGuard } from '@/components/auth/AuthRouteGuard';
import { AppTopBar } from '@/components/navigation/AppTopBar';
import { RoleBottomNav } from '@/components/navigation/RoleBottomNav';
import { AuthProvider } from '@/contexts/AuthContext';

export default function RootLayout() {
  const colorScheme = useColorScheme();

  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <FontScaleProvider>
      <AuthProvider>
        <AuthRouteGuard>
          <View style={{ flex: 1 }}>
            <AppTopBar />
            <View style={{ flex: 1 }}>
              <Stack initialRouteName="index" screenOptions={{ headerShown: false }}>
                <Stack.Screen name="index" />
              </Stack>
            </View>
            <RoleBottomNav />
          </View>
        </AuthRouteGuard>
      </AuthProvider>
      </FontScaleProvider>
    </ThemeProvider>
  );
}
