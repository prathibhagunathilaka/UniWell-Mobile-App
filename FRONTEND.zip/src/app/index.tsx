import { Redirect } from 'expo-router';
import { useEffect } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { UniWellLogo } from '@/components/brand/UniWellLogo';
import { InlineMessage, WellbeingIllustration } from '@/components/wellbeing/WellbeingUI';
import { WellbeingColors as Colors, WellbeingRadius as Radius, WellbeingSpace as Space } from '@/constants/wellbeingTheme';
import { getAuthenticatedHome, useAuth } from '@/contexts/AuthContext';

export default function IndexRoute() {
  const { user, loading, sessionNotice, beginAuthFlow } = useAuth();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    if (!loading) {
      console.info('[ROUTER] initial route decision:', user ? getAuthenticatedHome(user) : 'Welcome (unauthenticated)');
    }
  }, [loading, user]);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>Loading UniWell...</Text>
      </View>
    );
  }

  if (user) {
    return <Redirect href={getAuthenticatedHome(user)} />;
  }

  return (
    <ScrollView
      style={styles.page}
      contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + Space.lg }]}
      showsVerticalScrollIndicator={false}
      bounces={false}
    >
      <View style={styles.content}>
        <View style={styles.brand}>
          <UniWellLogo size={64} />
          <Text style={styles.brandName}>UniWell</Text>
        </View>

        <WellbeingIllustration label="A calm, welcoming illustration for university wellbeing" />

        <View style={styles.copy}>
          <Text style={styles.eyebrow}>A little space for you</Text>
          <Text style={styles.title}>Your Wellbeing Matters</Text>
          <Text style={styles.subtitle}>
            Take a moment to check in, find support, and access wellbeing resources designed for university life.
          </Text>
        </View>

        {sessionNotice ? <InlineMessage tone="error">{sessionNotice}</InlineMessage> : null}

        <View style={styles.actions}>
          <Pressable
            accessibilityRole="button"
            onPress={beginAuthFlow}
            style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}
          >
            <Text style={styles.primaryText}>GET STARTED</Text>
          </Pressable>
          <View style={styles.privacyCard}>
            <Text style={styles.privacyTitle}>A supportive space, on your terms</Text>
            <Text style={styles.privacyText}>Your check-ins are private to your account and are here to help you reflect.</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  // One centred column with even spacing, so the screen reads as a single composed block.
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: Space.lg,
    paddingTop: Space.md,
  },
  content: {
    width: '100%',
    maxWidth: 460,
    gap: Space.lg,
  },
  brand: {
    alignItems: 'center',
    gap: Space.sm,
  },
  brandName: {
    color: Colors.accent,
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  copy: {
    alignItems: 'center',
    gap: Space.sm,
  },
  actions: {
    gap: Space.md,
  },
  pressed: {
    opacity: 0.85,
  },
  eyebrow: {
    color: Colors.primary,
    fontWeight: '800',
    fontSize: 12,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  title: {
    color: Colors.accent,
    fontSize: 31,
    lineHeight: 38,
    fontWeight: '800',
    textAlign: 'center',
  },
  subtitle: {
    color: Colors.muted,
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'center',
  },
  primaryButton: {
    minHeight: 54,
    borderRadius: Radius.md,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryText: {
    color: Colors.accent,
    fontSize: 16,
    fontWeight: '800',
  },
  privacyCard: {
    backgroundColor: Colors.paleBlue,
    borderRadius: Radius.md,
    padding: Space.md,
    gap: Space.xs,
    alignItems: 'center',
  },
  privacyTitle: {
    color: Colors.accent,
    fontSize: 14,
    fontWeight: '800',
    textAlign: 'center',
  },
  privacyText: {
    color: Colors.muted,
    fontSize: 13,
    lineHeight: 19,
    textAlign: 'center',
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Space.sm,
    backgroundColor: Colors.background,
  },
  loadingText: {
    color: Colors.accent,
    fontSize: 15,
    fontWeight: '700',
  },
});
