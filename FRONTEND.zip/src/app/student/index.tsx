export { default } from './dashboard';

